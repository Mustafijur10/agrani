import type { Metadata } from "next";
import InfoCards, { contactInfo } from "@/components/contact/InfoCards";
import Contact from "@/components/Contact";
import { Pill, container } from "@/components/ui";

export const metadata: Metadata = {
  title: "Contact Us | Agrani Technologies & Services Limited",
  description: "Get in touch with Agrani Technologies & Services Limited: visit our Mirpur DOHS office, call, email or send us a message.",
};

// Keyless Google Maps embed. To pin the exact spot, open Google Maps → Share → Embed a map
// and paste that iframe's src here instead.
const mapSrc = `https://www.google.com/maps?q=${encodeURIComponent(contactInfo.address)}&z=16&output=embed`;

export default function ContactPage() {
  return (
    <>
      <section className="relative overflow-x-clip pb-16 lg:pb-24">
        <div aria-hidden className="pointer-events-none absolute -right-40 -top-40 h-[420px] w-[420px] rounded-full bg-[#F05827]/20 blur-3xl" />
        <div aria-hidden className="pointer-events-none absolute left-0 top-56 hidden h-20 w-40 rounded-t-full bg-gradient-to-b from-[#F05827]/70 to-transparent md:block" />
        <div aria-hidden className="pointer-events-none absolute -left-40 top-[620px] h-[360px] w-[420px] rounded-full bg-[#F05827]/20 blur-3xl" />
        <div aria-hidden className="pointer-events-none absolute -right-40 top-[560px] h-[420px] w-[360px] rounded-full bg-[#F05827]/15 blur-3xl" />

        <div className={`${container} relative`}>
          <div className="mx-auto max-w-[860px] text-center">
            <Pill>Contact Us</Pill>
            <h1 className="mt-6 text-4xl leading-tight text-[#051012] sm:text-5xl lg:text-[56px] dark:text-white">
              Need expert guidance? Reach out to our team—we&apos;d love to hear from you
            </h1>
            <p className="mx-auto mt-6 max-w-[760px] leading-7 text-[#3C3C3C] dark:text-[#B9B9B9]">
              Have a question or a project in mind? Send us a message or visit our office. We&apos;re available Monday to Friday, 9am–6pm.
            </p>
          </div>

          <div className="mt-14 h-[360px] overflow-hidden rounded-[32px] bg-[#E7ECEA] sm:h-[440px] lg:mt-24 lg:h-[500px]">
            <iframe
              title="Map showing the Agrani Technologies office in Mirpur DOHS, Dhaka"
              src={mapSrc}
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              allowFullScreen
              className="h-full w-full border-0 grayscale-[40%]"
            />
          </div>

          <div className="mt-8">
            <InfoCards />
          </div>
        </div>
      </section>

      <Contact />
    </>
  );
}
