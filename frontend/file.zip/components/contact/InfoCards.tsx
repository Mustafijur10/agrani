import { MapPin, Phone, Mail, Globe } from "lucide-react";
import type { ReactNode } from "react";

// Single source of truth for contact details (keep in sync with Footer).
export const contactInfo = {
  address: "Plot-174/176, Road-02, Avenue-01, Mirpur DOHS, Dhaka-1216, Bangladesh",
  phone: "+880-9610944449",
  email: "info@agranitechbd.com",
  website: "www.agranitechbd.com",
};

const card =
  "rounded-[32px] border border-black/10 bg-white/70 p-7 dark:border-white/15 dark:bg-white/5";
const link = "break-words hover:text-[#F05827] focus-visible:outline focus-visible:outline-2 focus-visible:outline-[#F05827]";

function Card({ icon, title, children }: { icon: ReactNode; title: string; children: ReactNode }) {
  return (
    <li className={card}>
      <span aria-hidden className="grid h-16 w-16 place-items-center rounded-full bg-[#F05827]/10 text-[#F05827]">{icon}</span>
      <h2 className="mt-5 text-xl text-[#051012] dark:text-white">{title}</h2>
      <div className="mt-3 text-[15px] leading-6 text-[#3C3C3C] dark:text-[#B9B9B9]">{children}</div>
    </li>
  );
}

export default function InfoCards() {
  const tel = contactInfo.phone.replace(/[^+\d]/g, "");
  return (
    <ul className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
      <Card icon={<MapPin size={28} />} title="Address">
        <address className="not-italic">{contactInfo.address}</address>
      </Card>
      <Card icon={<Phone size={28} />} title="Phone">
        <a href={`tel:${tel}`} className={link}>{contactInfo.phone}</a>
      </Card>
      <Card icon={<Mail size={28} />} title="Email">
        <a href={`mailto:${contactInfo.email}`} className={link}>{contactInfo.email}</a>
      </Card>
      <Card icon={<Globe size={28} />} title="Website">
        <a href={`https://${contactInfo.website}`} target="_blank" rel="noopener noreferrer" className={`${link} underline underline-offset-4`}>
          {contactInfo.website}
        </a>
      </Card>
    </ul>
  );
}
